#!/usr/bin/env python3
"""Capture the transponder's AIS output (or a receiver's) to timestamped JSONL.

Captures RAW lines only - never tries to decode at capture time, so a malformed
or partial received sentence is still recorded losslessly. Decoding happens
later in analyze.py. This is the ground-truth record for every experiment.

Run standalone:
    python3 capture.py --port /dev/ttyUSB1 --baud 38400 --out results/cap.jsonl
or import and use CaptureThread from the runner.
"""
import argparse, json, time, threading
import serial


class CaptureThread(threading.Thread):
    def __init__(self, port, baud, out_path, node="rx"):
        super().__init__(daemon=True)
        self.port = port; self.baud = baud
        self.out_path = out_path; self.node = node
        self._stop = threading.Event()
        self.lines = 0

    def run(self):
        try:
            ser = serial.Serial(self.port, self.baud, timeout=0.5)
        except Exception as e:
            with open(self.out_path, "a") as f:
                f.write(json.dumps({"t": time.time(), "node": self.node,
                                    "error": f"open failed: {e}"}) + "\n")
            return
        with open(self.out_path, "a", buffering=1) as f:
            while not self._stop.is_set():
                try:
                    raw = ser.readline()
                except Exception as e:
                    f.write(json.dumps({"t": time.time(), "node": self.node,
                                        "error": str(e)}) + "\n")
                    continue
                if not raw:
                    continue
                f.write(json.dumps({
                    "t": time.time(),
                    "node": self.node,
                    "raw": raw.decode("ascii", "replace").strip()
                }) + "\n")
                self.lines += 1
        ser.close()

    def stop(self):
        self._stop.set()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--port", default="/dev/ttyUSB1")
    p.add_argument("--baud", type=int, default=38400)
    p.add_argument("--out", default="capture.jsonl")
    p.add_argument("--node", default="rx")
    p.add_argument("--seconds", type=float, default=0, help="0 = until Ctrl-C")
    a = p.parse_args()
    cap = CaptureThread(a.port, a.baud, a.out, a.node)
    cap.start()
    print(f"capturing {a.port}@{a.baud} -> {a.out} (Ctrl-C to stop)")
    try:
        if a.seconds:
            time.sleep(a.seconds)
        else:
            while True:
                time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        cap.stop(); cap.join(timeout=2)
        print(f"stopped, {cap.lines} lines")


if __name__ == "__main__":
    main()
