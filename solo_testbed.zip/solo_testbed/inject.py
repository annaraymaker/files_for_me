#!/usr/bin/env python3
"""GPS injection into a transponder sensor port, and malformed-NMEA injection.

Modes:
  static   - hold one position (ghost ship)
  jump     - alternate between two positions (impossible jump)
  move     - dead-reckon along a course
  malformed- send the malformation library one item at a time

Every action logs a marker to an events.jsonl (via the `events` callback) so the
analyzer knows exactly when each thing happened. Designed to be driven by the
runner, but also runnable standalone for quick checks.
"""
import argparse, json, math, time
import serial
import nmea


def _emit(ser, dry, s):
    """s may be str (valid sentence) or bytes (malformed)."""
    data = s if isinstance(s, bytes) else (s + "\r\n").encode()
    if not isinstance(s, bytes):
        pass
    else:
        data = s + b"\r\n"
    if dry:
        print("  TX", data[:80])
    else:
        ser.write(data)


def _advance(lat, lon, sog_kts, cog_deg, dt):
    dist = sog_kts * 0.5144 * dt
    c = math.radians(cog_deg)
    lat2 = lat + (dist * math.cos(c)) / 111320.0
    lon2 = lon + (dist * math.sin(c)) / (111320.0 * math.cos(math.radians(lat)))
    return lat2, lon2


def run_static(ser, dry, lat, lon, duration, rate=1.0, events=None):
    end = time.time() + duration
    while time.time() < end:
        for s in nmea.full_batch(lat, lon):
            _emit(ser, dry, s)
        time.sleep(rate)


def run_jump(ser, dry, a, b, duration, hold=10.0, rate=1.0, events=None):
    """Alternate position a and b every `hold` seconds -> impossible jump."""
    end = time.time() + duration
    cur = a; nxt_swap = time.time() + hold; at_a = True
    while time.time() < end:
        if time.time() >= nxt_swap:
            at_a = not at_a
            cur = a if at_a else b
            nxt_swap = time.time() + hold
            if events:
                events({"event": "jump_to", "lat": cur[0], "lon": cur[1]})
        for s in nmea.full_batch(cur[0], cur[1]):
            _emit(ser, dry, s)
        time.sleep(rate)


def run_move(ser, dry, lat, lon, sog, cog, duration, rate=1.0, events=None):
    end = time.time() + duration
    while time.time() < end:
        for s in nmea.full_batch(lat, lon, sog, cog):
            _emit(ser, dry, s)
        lat, lon = _advance(lat, lon, sog, cog, rate)
        time.sleep(rate)


def run_malformed(ser, dry, gap=3.0, events=None, repeat=1):
    """Send each malformation, spaced by `gap` seconds, logging which/when."""
    for _ in range(repeat):
        for fn in nmea.MALFORMATIONS:
            label, payload = fn()
            if events:
                events({"event": "malformed_tx", "label": label,
                        "bytes": len(payload)})
            _emit(ser, dry, payload)
            time.sleep(gap)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--port", default="/dev/ttyUSB0")
    p.add_argument("--baud", type=int, default=4800)
    p.add_argument("--dry-run", action="store_true")
    sub = p.add_subparsers(dest="mode", required=True)
    s = sub.add_parser("static"); s.add_argument("lat", type=float); s.add_argument("lon", type=float); s.add_argument("--dur", type=float, default=30)
    j = sub.add_parser("jump"); j.add_argument("lat1", type=float); j.add_argument("lon1", type=float); j.add_argument("lat2", type=float); j.add_argument("lon2", type=float); j.add_argument("--dur", type=float, default=60); j.add_argument("--hold", type=float, default=10)
    m = sub.add_parser("move"); m.add_argument("lat", type=float); m.add_argument("lon", type=float); m.add_argument("--sog", type=float, default=8); m.add_argument("--cog", type=float, default=90); m.add_argument("--dur", type=float, default=60)
    mf = sub.add_parser("malformed"); mf.add_argument("--gap", type=float, default=3)
    a = p.parse_args()

    ser = None if a.dry_run else serial.Serial(a.port, a.baud, timeout=1)
    ev = lambda d: print("  EVENT", d)
    if a.mode == "static":
        run_static(ser, a.dry_run, a.lat, a.lon, a.dur, events=ev)
    elif a.mode == "jump":
        run_jump(ser, a.dry_run, (a.lat1, a.lon1), (a.lat2, a.lon2), a.dur, a.hold, events=ev)
    elif a.mode == "move":
        run_move(ser, a.dry_run, a.lat, a.lon, a.sog, a.cog, a.dur, events=ev)
    elif a.mode == "malformed":
        run_malformed(ser, a.dry_run, a.gap, events=ev)
    if ser:
        ser.close()


if __name__ == "__main__":
    main()
