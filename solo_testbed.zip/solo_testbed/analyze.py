#!/usr/bin/env python3
"""Analyze a completed run folder into summary.json + a printed verdict.

Reads capture.jsonl (raw AIS) and events.jsonl (markers), decodes AIS with pyais
(handling multi-fragment type 5), and evaluates the experiment's `expect` block:

  position_reports  - did we see any type 1/2/3 position report?
  near              - were reports near the injected lat/lon?
  jump_detected     - was there a between-report jump >= jump_min_km?
  mmsi_prefix       - did transmitted MMSI carry the configured prefix?
  ceases            - did reports stop after injection ended (disappearance)?
  survives          - (malformed) did output continue / not wedge?

Decoding is best-effort: malformed/garbled lines are counted, not fatal.
"""
import json, os, sys, math
from datetime import datetime, timezone

try:
    from pyais import decode as ais_decode
    from pyais.messages import NMEAMessage
    HAVE_PYAIS = True
except Exception:
    HAVE_PYAIS = False


def _haversine_km(a, b):
    R = 6371.0
    la1, lo1, la2, lo2 = map(math.radians, [a[0], a[1], b[0], b[1]])
    dla = la2 - la1; dlo = lo2 - lo1
    h = math.sin(dla/2)**2 + math.cos(la1)*math.cos(la2)*math.sin(dlo/2)**2
    return 2 * R * math.asin(math.sqrt(h))


def load(path):
    rows = []
    if not os.path.exists(path):
        return rows
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    rows.append(json.loads(line))
                except Exception:
                    pass
    return rows


def decode_capture(cap):
    """Return list of decoded position/static dicts: {t, mmsi, type, lat, lon}.
    Reassembles multi-fragment sentences by sequence/fragment when possible.
    """
    decoded = []
    frag_buf = {}
    counts = {"total": 0, "ais_lines": 0, "decoded": 0, "undecodable": 0}
    for row in cap:
        raw = row.get("raw", "")
        counts["total"] += 1
        if not raw.startswith("!AIVD"):
            continue
        counts["ais_lines"] += 1
        if not HAVE_PYAIS:
            continue
        try:
            parts = raw.split(",")
            frag_total = int(parts[1]); frag_num = int(parts[2]); seq = parts[3]
            if frag_total == 1:
                msg = ais_decode(raw)
                _collect(msg, row["t"], decoded, counts)
            else:
                key = seq or "_"
                frag_buf.setdefault(key, {})[frag_num] = raw
                if len(frag_buf[key]) == frag_total:
                    ordered = [frag_buf[key][i] for i in range(1, frag_total+1)]
                    msg = ais_decode(*ordered)
                    _collect(msg, row["t"], decoded, counts)
                    frag_buf.pop(key, None)
        except Exception:
            counts["undecodable"] += 1
    return decoded, counts


def _collect(msg, t, decoded, counts):
    d = msg.asdict() if hasattr(msg, "asdict") else dict(msg)
    mt = d.get("msg_type")
    entry = {"t": t, "mmsi": d.get("mmsi"), "type": mt}
    if "lat" in d and d.get("lat") is not None:
        entry["lat"] = d["lat"]; entry["lon"] = d["lon"]
    decoded.append(entry)
    counts["decoded"] += 1


def analyze(rundir):
    meta = json.load(open(os.path.join(rundir, "metadata.json")))
    cap = load(os.path.join(rundir, "capture.jsonl"))
    events = load(os.path.join(rundir, "events.jsonl"))
    decoded, counts = decode_capture(cap)
    expect = meta.get("expect", {})

    pos = [d for d in decoded if d["type"] in (1, 2, 3) and "lat" in d]
    summary = {
        "experiment": meta["experiment"],
        "counts": counts,
        "position_report_count": len(pos),
        "checks": {},
    }

    # position_reports
    if "position_reports" in expect:
        summary["checks"]["position_reports"] = {
            "expected": expect["position_reports"],
            "observed": len(pos) > 0,
            "pass": (len(pos) > 0) == expect["position_reports"],
        }

    # near injected position
    if "near" in expect and pos:
        tgt = expect["near"]
        dists = [_haversine_km((p["lat"], p["lon"]), tgt) for p in pos]
        summary["checks"]["near"] = {
            "target": tgt, "min_km": round(min(dists), 3),
            "max_km": round(max(dists), 3),
            "pass": min(dists) < 1.0,
        }

    # impossible jump
    if expect.get("jump_detected") and len(pos) >= 2:
        max_jump = 0.0
        for i in range(1, len(pos)):
            if "lat" in pos[i-1] and "lat" in pos[i]:
                km = _haversine_km((pos[i-1]["lat"], pos[i-1]["lon"]),
                                   (pos[i]["lat"], pos[i]["lon"]))
                max_jump = max(max_jump, km)
        thr = expect.get("jump_min_km", 50)
        summary["checks"]["jump_detected"] = {
            "max_jump_km": round(max_jump, 2), "threshold_km": thr,
            "pass": max_jump >= thr,
        }

    # mmsi prefix
    if "mmsi_prefix" in expect:
        prefixes = {str(p["mmsi"])[:len(expect["mmsi_prefix"])]
                    for p in decoded if p.get("mmsi")}
        summary["checks"]["mmsi_prefix"] = {
            "expected_prefix": expect["mmsi_prefix"],
            "observed_prefixes": sorted(prefixes),
            "pass": expect["mmsi_prefix"] in prefixes,
        }

    # disappearance: did reports cease after inject_stop?
    if expect.get("ceases"):
        stop_t = next((e["t"] for e in events if e.get("event") == "inject_stop"), None)
        after = [p for p in pos if stop_t and p["t"] > stop_t + 5]
        last_t = max((p["t"] for p in pos), default=None)
        gap_after_stop = (last_t - stop_t) if (last_t and stop_t) else None
        summary["checks"]["ceases"] = {
            "inject_stop_t": stop_t,
            "reports_after_stop+5s": len(after),
            "last_report_relative_to_stop_s":
                round(gap_after_stop, 1) if gap_after_stop is not None else None,
            "pass": len(after) == 0,
        }

    # malformed survival: was there output, and which malformations were sent
    if expect.get("survives"):
        sent = [e for e in events if e.get("event") == "malformed_tx"]
        summary["checks"]["survives"] = {
            "malformations_sent": [e["label"] for e in sent],
            "ais_lines_during_run": counts["ais_lines"],
            "note": "PASS here only means output didn't vanish; inspect "
                    "capture.jsonl manually for resets/garbage/accepted-bad-data.",
            "pass": counts["ais_lines"] > 0,
        }

    overall = all(c.get("pass", True) for c in summary["checks"].values())
    summary["overall_pass"] = overall

    with open(os.path.join(rundir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    # printed verdict
    print(f"\n=== {meta['experiment']} ===")
    print(f"AIS lines: {counts['ais_lines']}  decoded: {counts['decoded']}  "
          f"position reports: {len(pos)}")
    for name, c in summary["checks"].items():
        mark = "PASS" if c.get("pass") else "FAIL"
        print(f"  [{mark}] {name}: "
              f"{ {k:v for k,v in c.items() if k!='pass'} }")
    print(f"OVERALL: {'PASS' if overall else 'REVIEW'}")
    if not HAVE_PYAIS:
        print("  (pyais not installed: install it for decoding)")
    return summary


def main():
    if len(sys.argv) < 2:
        sys.exit("usage: python3 analyze.py results/<rundir>")
    analyze(sys.argv[1])


if __name__ == "__main__":
    main()
