#!/usr/bin/env python3
"""The six solo experiments, defined as DATA.

Each entry says what to inject, for how long, what manual transponder config it
needs first (if any), and what the analyzer should check for. Adding/altering an
experiment means editing this dict - never the runner.

Coordinates below are placeholders (Massachusetts Bay-ish). Change freely.
Identities use TEST / reserved-pattern MMSIs so nothing resembles a real vessel.

MMSI prefix reference (ITU):
  111MIDxxx  SAR aircraft
  970yyzzzz  AIS-SART (search & rescue transmitter)
  972yyzzzz  MOB (man overboard)
  974yyzzzz  EPIRB-AIS
  99MIDxxxx  Aid to Navigation
  00MIDxxxx  base/coast station (a mobile sending this is structurally invalid)
"""

EXPERIMENTS = {

    "ghost_static": {
        "desc": "Fake position (ghost ship): hold an IMPOSSIBLE static position.",
        "manual_config": None,
        # On land in Kansas - a vessel here is physically impossible, so this
        # tests whether the transponder/receiver accepts/renders it anyway.
        "action": {"mode": "static", "lat": 39.0000, "lon": -100.0000, "dur": 60},
        "expect": {"position_reports": True,
                   "near": (39.0000, -100.0000)},
        "notes": "Vessel placed on land. Receiver should show it there if no "
                 "plausibility check exists. Change coords in experiments.py to "
                 "test a plausible spot, Null Island (0,0), poles, etc.",
    },

    "ghost_sweep": {
        "desc": "Ghost ship at several positions across plausibility classes.",
        "manual_config": None,
        "action": {"mode": "sweep", "hold": 20, "positions": [
            [42.3500, -70.9000],    # plausible: Massachusetts Bay
            [0.0,      0.0],         # Null Island: ocean off Africa (classic error)
            [39.0000, -100.0000],   # on land: Kansas (physically impossible)
            [89.9000,  0.0000],     # near North Pole
        ]},
        "expect": {"position_reports": True},
        "notes": "Each position held 20s; events.jsonl logs a sweep_to marker at "
                 "each. Check per-position in capture.jsonl whether the receiver "
                 "accepts/renders/flags each one. Edit the positions list freely.",
    },

    "impossible_jump": {
        "desc": "Impossible jump: teleport between two far-apart positions.",
        "manual_config": None,
        "action": {"mode": "jump",
                   "a": (42.3500, -70.9000), "b": (41.0000, -69.0000),
                   "dur": 120, "hold": 15},
        "expect": {"position_reports": True, "jump_detected": True,
                   "jump_min_km": 50},
        "notes": "Implies a speed no real vessel can achieve between reports.",
    },

    "fake_identity_class": {
        "desc": "Fake identity-class: transmit under a SAR-aircraft MMSI prefix.",
        "manual_config": {"mmsi": "111257001",
                          "why": "111 = SAR aircraft; a surface ship using it "
                                 "is an identity-class spoof."},
        "action": {"mode": "static", "lat": 42.4000, "lon": -70.8000, "dur": 60},
        "expect": {"position_reports": True, "mmsi_prefix": "111"},
        "notes": "Set MMSI on the unit's menu FIRST, then run. Observe how the "
                 "receiver/chartplotter classifies/labels the target.",
    },

    "fake_epirb_location": {
        "desc": "Combined: EPIRB-AIS identity at a chosen fake location.",
        "manual_config": {"mmsi": "974257001",
                          "why": "974 = EPIRB-AIS; pairing it with a spoofed "
                                 "position fakes a distress beacon at a place."},
        "action": {"mode": "static", "lat": 42.2500, "lon": -70.7500, "dur": 60},
        "expect": {"position_reports": True, "mmsi_prefix": "974"},
        "notes": "Set MMSI 974xxxxxx on the unit FIRST. Watch whether the "
                 "receiver raises a distress/SART-class indication.",
    },

    "disappearance": {
        "desc": "Disappearance: transmit, then stop; watch for target-lost.",
        "manual_config": None,
        # phase1: inject for `dur`, then runner STOPS injecting and keeps
        # capturing for `silence` more seconds.
        "action": {"mode": "static", "lat": 42.3500, "lon": -70.9000,
                   "dur": 60, "silence": 90},
        "expect": {"position_reports": True, "ceases": True},
        "notes": "After injection stops the unit loses its fix; reports should "
                 "cease. Note if/when the receiver alarms 'lost target'.",
    },

    "malformed_nmea": {
        "desc": "Malformed NMEA to transponder sensor input.",
        "manual_config": None,
        "action": {"mode": "malformed", "gap": 4, "repeat": 1},
        "expect": {"survives": True},
        "notes": "Sends a library of broken NMEA. Watch the unit for resets, "
                 "hangs, garbage output, or accepting bad data. events.jsonl "
                 "records which malformation was sent when.",
    },
}
