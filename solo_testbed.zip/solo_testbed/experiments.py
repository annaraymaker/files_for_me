#!/usr/bin/env python3
"""The six solo experiments, defined as DATA.

Each entry says what to inject, for how long, what manual transponder config it
needs first (if any), and what the analyzer should check for. Adding/altering an
experiment means editing this dict - never the runner.

Coordinates below are placeholders (Massachusetts Bay-ish). Change freely.
Identities use TEST / reserved-pattern MMSIs so nothing resembles a real vessel.

MMSI prefix reference (ITU):
  111MIDxxx  SAR aircraft
  970yyzzzz  AIS-SART (search & rescue transmitter)
  972yyzzzz  MOB (man overboard)
  974yyzzzz  EPIRB-AIS
  99MIDxxxx  Aid to Navigation
  00MIDxxxx  base/coast station (a mobile sending this is structurally invalid)
"""

EXPERIMENTS = {

    "ghost_static": {
        "desc": "Fake position (ghost ship): hold an IMPOSSIBLE static position.",
        "manual_config": None,
        # On land in Kansas - a vessel here is physically impossible, so this
        # tests whether the transponder/receiver accepts/renders it anyway.
        "action": {"mode": "static", "lat": 39.0000, "lon": -100.0000, "dur": 60},
        "expect": {"position_reports": True,
                   "near": (39.0000, -100.0000)},
        "notes": "Vessel placed on land. Receiver should show it there if no "
                 "plausibility check exists. Change coords in experiments.py to "
                 "test a plausible spot, Null Island (0,0), poles, etc.",
    },

    "parser_length_sweep": {
        "desc": "DoS: sweep oversized line lengths, measure how long legitimate "
                "reporting is suppressed (probes IEC 61162-1 max-length non-enforcement).",
        "manual_config": None,
        "analyzer": "analyze_dos.py",
        "action": {"mode": "dos_lengthsweep",
                   "baseline": [42.3500, -70.9000],
                   "lengths": [82, 200, 512, 1024, 2048, 4096, 8192, 16384],
                   "settle": 20, "recover": 30},
        "expect": {},
        "notes": "Valid GPS baseline first (so there's real reporting to deny), "
                 "then one oversized line per length with recovery between. "
                 "Analyzer plots suppression-vs-length: linear with transmit time "
                 "= no length enforcement (DoS scales with line size); super-linear "
                 "excess = a worse parser bug. Add bigger lengths (65536+) to push "
                 "further - each ~doubles the time at 4800 baud.",
    },

    "unterminated_hold": {
        "desc": "DoS: send a long run of bytes with NO terminator; test whether "
                "the parser blocks waiting for end-of-sentence.",
        "manual_config": None,
        "analyzer": "analyze_dos.py",
        "action": {"mode": "unterminated", "baseline": [42.3500, -70.9000],
                   "total_bytes": 4000, "settle": 20, "recover": 40},
        "expect": {},
        "notes": "If suppression greatly exceeds the raw transmit time for "
                 "total_bytes, the parser is stalling on the missing terminator - "
                 "a stronger DoS than the length sweep. Try increasing total_bytes.",
    },

    "flood_dos": {
        "desc": "DoS: saturate the sensor channel with back-to-back junk for a "
                "duration; measure sustained suppression and recovery time.",
        "manual_config": None,
        "analyzer": "analyze_dos.py",
        "action": {"mode": "flood", "baseline": [42.3500, -70.9000],
                   "duration": 30, "settle": 20, "recover": 30},
        "expect": {},
        "notes": "Models an attacker holding the line. Measures whether the unit "
                 "stays no-fix for the whole flood and how fast it recovers after.",
    },

    "alert_trigger": {
        "desc": "Characterize which malformed inputs trigger AIS alert output "
                "($AIALC/ALR/PFEC) and whether the alerts can be sustained.",
        "manual_config": None,
        "analyzer": "analyze_dos.py",
        "action": {"mode": "alert_probe", "baseline": [42.3500, -70.9000],
                   "settle": 15, "hold": 12, "recover": 8},
        "expect": {},
        "notes": "Repeats each malformation for `hold` seconds. Analyzer counts "
                 "alert sentences per probe so you can see which inputs raise "
                 "alarms (you already saw too_few_fields and the huge line do) "
                 "and whether sustained input sustains the alert storm.",
    },

    "impossible_coords": {
        "desc": "Sweep out-of-range / impossible coordinate VALUES (valid NMEA "
                "structure) to characterize transponder input validation.",
        "manual_config": None,
        "action": {"mode": "badcoords", "hold": 15, "entries": [
            # out-of-range decimal degrees
            {"label": "lat_91_just_past_north_pole",  "lat": 91.0,  "lon": -70.0},
            {"label": "lat_100_far_past_pole",        "lat": 100.0, "lon": -70.0},
            {"label": "lat_neg91_past_south_pole",    "lat": -91.0, "lon": -70.0},
            {"label": "lon_181_just_past_antimerid",  "lat": 42.0,  "lon": 181.0},
            {"label": "lon_200_far_east",             "lat": 42.0,  "lon": 200.0},
            {"label": "lon_360_full_wrap",            "lat": 42.0,  "lon": 360.0},
            {"label": "lon_neg181_past_west",         "lat": 42.0,  "lon": -181.0},
            {"label": "ais_no_fix_sentinel_91_181",   "lat": 91.0,  "lon": 181.0},
            {"label": "both_absurd_99_250",           "lat": 99.0,  "lon": 250.0},
            # raw-field impossibles the decimal path can't express
            {"label": "minutes_eq_60", "lat_raw": "4260.0000", "lat_h": "N",
             "lon_raw": "07054.0000", "lon_h": "W"},
            {"label": "minutes_99", "lat_raw": "4299.9999", "lat_h": "N",
             "lon_raw": "07054.0000", "lon_h": "W"},
            {"label": "lat_field_overlong", "lat_raw": "999999.9999", "lat_h": "N",
             "lon_raw": "07054.0000", "lon_h": "W"},
            {"label": "bad_hemisphere_Q", "lat_raw": "4221.0000", "lat_h": "Q",
             "lon_raw": "07054.0000", "lon_h": "Z"},
        ]},
        "expect": {"survives": True},
        "notes": "Structurally valid NMEA carrying impossible coordinate values. "
                 "IMPORTANT: the transponder re-encodes position before it "
                 "transmits, so this mainly probes how each unit validates bad "
                 "GPS *input* (reject / clamp / transmit the 91/181 'no-fix' "
                 "sentinel / misbehave). Read capture.jsonl against the badcoord "
                 "markers in events.jsonl, and check summary.json's "
                 "'distinct_positions_transmitted' to see what actually went out "
                 "per bad value. Receiver-side out-of-range handling is a "
                 "separate SDR-phase experiment (craft the bits directly).",
    },

    "ghost_sweep": {
        "desc": "Ghost ship at several positions across plausibility classes.",
        "manual_config": None,
        "action": {"mode": "sweep", "hold": 20, "positions": [
            [42.3500, -70.9000],    # plausible: Massachusetts Bay
            [0.0,      0.0],         # Null Island: ocean off Africa (classic error)
            [39.0000, -100.0000],   # on land: Kansas (physically impossible)
            [89.9000,  0.0000],     # near North Pole
        ]},
        "expect": {"position_reports": True},
        "notes": "Each position held 20s; events.jsonl logs a sweep_to marker at "
                 "each. Check per-position in capture.jsonl whether the receiver "
                 "accepts/renders/flags each one. Edit the positions list freely.",
    },

    "impossible_jump": {
        "desc": "Impossible jump: teleport between two far-apart positions.",
        "manual_config": None,
        "action": {"mode": "jump",
                   "a": (42.3500, -70.9000), "b": (41.0000, -69.0000),
                   "dur": 120, "hold": 15},
        "expect": {"position_reports": True, "jump_detected": True,
                   "jump_min_km": 50},
        "notes": "Implies a speed no real vessel can achieve between reports.",
    },

    "fake_identity_class": {
        "desc": "Fake identity-class: transmit under a SAR-aircraft MMSI prefix.",
        "manual_config": {"mmsi": "111257001",
                          "why": "111 = SAR aircraft; a surface ship using it "
                                 "is an identity-class spoof."},
        "action": {"mode": "static", "lat": 42.4000, "lon": -70.8000, "dur": 60},
        "expect": {"position_reports": True, "mmsi_prefix": "111"},
        "notes": "Set MMSI on the unit's menu FIRST, then run. Observe how the "
                 "receiver/chartplotter classifies/labels the target.",
    },

    "fake_epirb_location": {
        "desc": "Combined: EPIRB-AIS identity at a chosen fake location.",
        "manual_config": {"mmsi": "974257001",
                          "why": "974 = EPIRB-AIS; pairing it with a spoofed "
                                 "position fakes a distress beacon at a place."},
        "action": {"mode": "static", "lat": 42.2500, "lon": -70.7500, "dur": 60},
        "expect": {"position_reports": True, "mmsi_prefix": "974"},
        "notes": "Set MMSI 974xxxxxx on the unit FIRST. Watch whether the "
                 "receiver raises a distress/SART-class indication.",
    },

    "disappearance": {
        "desc": "Disappearance: transmit, then stop; watch for target-lost.",
        "manual_config": None,
        # phase1: inject for `dur`, then runner STOPS injecting and keeps
        # capturing for `silence` more seconds.
        "action": {"mode": "static", "lat": 42.3500, "lon": -70.9000,
                   "dur": 60, "silence": 90},
        "expect": {"position_reports": True, "ceases": True},
        "notes": "After injection stops the unit loses its fix; reports should "
                 "cease. Note if/when the receiver alarms 'lost target'.",
    },

    "malformed_nmea": {
        "desc": "Malformed NMEA to transponder sensor input.",
        "manual_config": None,
        "action": {"mode": "malformed", "gap": 4, "repeat": 1},
        "expect": {"survives": True},
        "notes": "Sends a library of broken NMEA. Watch the unit for resets, "
                 "hangs, garbage output, or accepting bad data. events.jsonl "
                 "records which malformation was sent when.",
    },
}
