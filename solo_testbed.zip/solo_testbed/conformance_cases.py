#!/usr/bin/env python3
"""Spec-conformance test cases (IEC 61162-1 / NMEA 0183 sentence structure).

Each case is a dict:
    id        unique short id (stable - the SDR phase will reuse these ids)
    category  grouping for the rollup
    spec      what rule it probes (for the paper's clause column)
    transport "serial" (sensor port) or "aivdm" (reusable verbatim by the RF phase)
    expect    the CONFORMANT listener behavior, in plain words
    gen()     -> raw bytes to transmit (bytes, so we can emit non-ASCII / no-CRLF)

Design rules baked in from the spec answers:
  - terminator is exactly <CR><LF>           (bare CR / bare LF / LF-CR are violations)
  - checksum mandatory in ALL sentences      (missing checksum is a violation)
  - address field: digits + UPPERCASE only   (lowercase / specials are violations)
  - no universal per-field max; only 82-char whole-sentence max ...
  - ...but sentence-specific field limits: VER f4<=15 f5<=32; SMV name<=30 (LISTENER
    must accept and TRUNCATE to 30, not reject); SMB<=58; VDM/DO encap 60 (62 special)
  - AIVDM/AIVDO are 0183-defined: we inject them on SERIAL here and tag transport
    "aivdm" so the RF phase can replay the identical bytes -> serial-vs-RF comparison.

Conformant baseline for comparison: a valid GPRMC/GPGGA at the baseline position.
Most malformed cases SHOULD be silently rejected (output stays on last good fix);
"accepted" (output changes to reflect bad input) is the security-relevant violation.
"""
from nmea import checksum, sentence

CR = b"\r"
LF = b"\n"
CRLF = b"\r\n"

# a known-good body we mutate (valid GPRMC at the baseline position 42.35/-70.90)
_GOOD_BODY = "GPRMC,120000.00,A,4221.0000,N,07054.0000,W,0.0,90.0,180626,,,A"


def _ok(body):
    """complete, valid sentence bytes from a body (no $, no *cc)."""
    return (sentence(body) + "\r\n").encode()


def _raw(s):
    return s if isinstance(s, bytes) else s.encode()


# ---- helpers to build specific sentence types at exact field lengths ----
def _ver(uid_len, data_len):
    # VER: $--VER,x,x,c--c(f4 uid<=15),c--c(f5 data<=32),...  (probe f4/f5 limits)
    body = f"GPVER,1,1,{'U'*uid_len},{'D'*data_len},1,1"
    return _ok(body)


def _smv_name(n):
    # SMV-style sentence carrying a vessel name field of length n (limit 30, truncate)
    body = f"GPSMV,1,1,{'X'*n}"
    return _ok(body)


def _aivdm(frag_total, frag_num, seq, channel, payload, fill):
    seq = "" if seq is None else str(seq)
    body = f"AIVDM,{frag_total},{frag_num},{seq},{channel},{payload},{fill}"
    return _ok(body)


# valid-ish single-fragment AIVDM type-1 payload (15 chars, 6-bit armored)
_AIVDM_PAYLOAD = "15M67FC000G?ufbE`FepT@2HFt"


CASES = []
def C(id, category, spec, transport, expect, gen):
    CASES.append({"id": id, "category": category, "spec": spec,
                  "transport": transport, "expect": expect, "gen": gen})


# ============================ CONTROL ============================
C("control_valid", "control", "valid sentence", "serial",
  "ACCEPT - unit keeps reporting a valid fix (proves rig works)",
  lambda: _ok(_GOOD_BODY))

# ====================== SENTENCE STRUCTURE ======================
C("struct_no_start_delim", "structure", "start delimiter $ or ! required", "serial",
  "REJECT - no leading $/!",
  lambda: (_GOOD_BODY + "*" + checksum(_GOOD_BODY) + "\r\n").encode())
C("struct_wrong_start_delim", "structure", "start delimiter must be $ or !", "serial",
  "REJECT - '#' is not a valid start delimiter",
  lambda: ("#" + _GOOD_BODY + "*" + checksum(_GOOD_BODY) + "\r\n").encode())
C("struct_missing_terminator", "structure", "terminator must be <CR><LF>", "serial",
  "REJECT/await - no CRLF at all",
  lambda: _raw(sentence(_GOOD_BODY)))
C("struct_only_cr", "structure", "terminator must be <CR><LF>", "serial",
  "REJECT - bare CR, no LF",
  lambda: _raw(sentence(_GOOD_BODY)) + CR)
C("struct_only_lf", "structure", "terminator must be <CR><LF>", "serial",
  "REJECT - bare LF, no CR",
  lambda: _raw(sentence(_GOOD_BODY)) + LF)
C("struct_lf_cr_order", "structure", "terminator order is CR then LF", "serial",
  "REJECT - LF before CR",
  lambda: _raw(sentence(_GOOD_BODY)) + LF + CR)
C("struct_multi_start", "structure", "single start delimiter", "serial",
  "REJECT - two start delimiters",
  lambda: ("$$" + _GOOD_BODY + "*" + checksum(_GOOD_BODY) + "\r\n").encode())
C("struct_multi_end", "structure", "single checksum/terminator", "serial",
  "REJECT - doubled terminator",
  lambda: _raw(sentence(_GOOD_BODY)) + CRLF + CRLF)
C("struct_leading_garbage", "structure", "resync on start delimiter", "serial",
  "tolerate/resync - junk before $ then a valid sentence",
  lambda: b"GARBAGE\x01\x02" + _ok(_GOOD_BODY))
C("struct_trailing_garbage", "structure", "checksum is last field", "serial",
  "REJECT - extra bytes after checksum before CRLF",
  lambda: (sentence(_GOOD_BODY) + "TRAILING").encode() + CRLF)
C("struct_just_over_82_83", "structure", "82-char max sentence", "serial",
  "REJECT - 83-char sentence (1 over limit)",
  lambda: _ok("GPRMC,120000.00,A,4221.0000,N,07054.0000,W,0.0," + "9"*7))
C("struct_just_over_82_90", "structure", "82-char max sentence", "serial",
  "REJECT - ~90-char sentence",
  lambda: _ok("GPRMC,120000.00,A,4221.0000,N,07054.0000,W,0.0," + "9"*14))

# ====================== CHECKSUM ======================
C("cks_wrong_value", "checksum", "checksum must match", "serial",
  "REJECT - checksum doesn't match body",
  lambda: ("$" + _GOOD_BODY + "*00\r\n").encode())
C("cks_missing", "checksum", "checksum mandatory in all sentences", "serial",
  "REJECT - no checksum field at all",
  lambda: ("$" + _GOOD_BODY + "\r\n").encode())
C("cks_nonhex", "checksum", "checksum is hex", "serial",
  "REJECT - 'ZZ' not hex",
  lambda: ("$" + _GOOD_BODY + "*ZZ\r\n").encode())
C("cks_one_digit", "checksum", "checksum is two hex digits", "serial",
  "REJECT - single hex digit",
  lambda: ("$" + _GOOD_BODY + "*" + checksum(_GOOD_BODY)[0] + "\r\n").encode())
C("cks_three_digit", "checksum", "checksum is two hex digits", "serial",
  "REJECT - three hex digits",
  lambda: ("$" + _GOOD_BODY + "*" + checksum(_GOOD_BODY) + "F\r\n").encode())
C("cks_lowercase", "checksum", "checksum hex uppercase", "serial",
  "REJECT/flag - lowercase hex checksum",
  lambda: ("$" + _GOOD_BODY + "*" + checksum(_GOOD_BODY).lower() + "\r\n").encode())
C("cks_wrong_range", "checksum", "checksum XOR excludes $ and *", "serial",
  "REJECT - plausible value computed over wrong range (incl $)",
  lambda: ("$" + _GOOD_BODY + "*" + checksum("$" + _GOOD_BODY) + "\r\n").encode())

# ====================== INVALID CHARACTERS ======================
C("chr_null_byte", "characters", "printable ASCII only", "serial",
  "REJECT - embedded NUL",
  lambda: ("$" + _GOOD_BODY.replace("A,", "A\x00,", 1) + "*" + checksum(_GOOD_BODY) + "\r\n").encode())
C("chr_control", "characters", "printable ASCII only", "serial",
  "REJECT - control chars (0x07,0x1B) in field",
  lambda: ("$GPRMC,120000.00,A,4221.0000,\x07\x1B,07054.0000,W,0.0,0.0,180626,,,A*00\r\n").encode())
C("chr_high_ascii", "characters", "printable ASCII (<128)", "serial",
  "REJECT - high-ASCII bytes 0x80-0xFF",
  lambda: b"$GPRMC,120000.00,A," + bytes([0x80, 0xC3, 0xFF]) + b",N,07054.0,W,0,0,180626,,,A*00\r\n")
C("chr_tab", "characters", "printable ASCII only", "serial",
  "REJECT - tab char in field",
  lambda: ("$GPRMC,120000.00,A,4221.0000,\tN,07054.0000,W,0.0,0.0,180626,,,A*00\r\n").encode())
C("chr_embedded_nul_midsentence", "characters", "no NUL in sentence", "serial",
  "REJECT - NUL mid valid sentence (C-string truncation bug probe)",
  lambda: ("$" + _GOOD_BODY[:20]).encode() + b"\x00" + (_GOOD_BODY[20:] + "*00\r\n").encode())

# ====================== RESERVED CHARS IN DATA ======================
C("rsv_dollar_in_data", "reserved", "$ only as start delimiter", "serial",
  "REJECT - $ inside a data field",
  lambda: ("$GPRMC,1200$00.00,A,4221.0000,N,07054.0000,W,0,0,180626,,,A*00\r\n").encode())
C("rsv_bang_in_data", "reserved", "! only as encapsulation start", "serial",
  "REJECT - ! inside a data field",
  lambda: ("$GPRMC,1200!00.00,A,4221.0000,N,07054.0000,W,0,0,180626,,,A*00\r\n").encode())
C("rsv_star_in_data", "reserved", "* only introduces checksum", "serial",
  "REJECT - * inside data before real checksum",
  lambda: ("$GPRMC,120000.00,A,4221.0000,N,07054.0000,W,0,0,180626,,,A*FF*" + checksum(_GOOD_BODY) + "\r\n").encode())
C("rsv_cr_in_data", "reserved", "CR/LF only in terminator", "serial",
  "REJECT - CR inside a data field",
  lambda: b"$GPRMC,120000.00,A,4221.0000\r,N,07054.0,W,0,0,180626,,,A*00\r\n")

# ====================== ADDRESS FIELD ======================
C("addr_talker_too_short", "address", "talker ID 2 chars", "serial",
  "REJECT - 1-char talker",
  lambda: _ok("GRMC,120000.00,A,4221.0000,N,07054.0000,W,0,0,180626,,,A"))
C("addr_talker_too_long", "address", "talker ID 2 chars", "serial",
  "REJECT - address field too long",
  lambda: _ok("GPSXRMC,120000.00,A,4221.0000,N,07054.0000,W,0,0,180626,,,A"))
C("addr_lowercase", "address", "address field UPPERCASE only", "serial",
  "REJECT - lowercase address $gpgga",
  lambda: ("$gprmc,120000.00,A,4221.0000,N,07054.0000,W,0,0,180626,,,a*00\r\n").encode())
C("addr_numbers_in_talker", "address", "talker ID letters", "serial",
  "REJECT - digits in talker ID",
  lambda: _ok("G1RMC,120000.00,A,4221.0000,N,07054.0000,W,0,0,180626,,,A"))
C("addr_special_chars", "address", "address digits+uppercase only", "serial",
  "REJECT - special chars in address",
  lambda: ("$GP#MC,120000.00,A,4221.0000,N,07054.0000,W,0,0,180626,,,A*00\r\n").encode())
C("addr_formatter_too_short", "address", "sentence formatter 3 chars", "serial",
  "REJECT - 2-char formatter",
  lambda: _ok("GPRM,120000.00,A,4221.0000,N,07054.0000,W,0,0,180626,,,A"))
C("addr_formatter_too_long", "address", "sentence formatter 3 chars", "serial",
  "REJECT - 4-char formatter",
  lambda: _ok("GPRMCX,120000.00,A,4221.0000,N,07054.0000,W,0,0,180626,,,A"))
C("addr_undefined_talker", "address", "defined talker IDs", "serial",
  "ignore/reject - undefined talker XX",
  lambda: _ok("XXRMC,120000.00,A,4221.0000,N,07054.0000,W,0,0,180626,,,A"))
C("addr_undefined_formatter", "address", "defined sentence formatters", "serial",
  "ignore/reject - undefined formatter GPZZZ",
  lambda: _ok("GPZZZ,120000.00,A,4221.0000,N,07054.0000,W,0,0,180626,,,A"))

# ====================== DATA FIELDS ======================
C("data_all_empty", "datafields", "field structure", "serial",
  "ignore/reject - all fields empty",
  lambda: _ok("GPRMC,,,,,,,,,,,,"))
C("data_required_empty_time", "datafields", "required field present", "serial",
  "REJECT/ignore - empty time in RMC",
  lambda: _ok("GPRMC,,A,4221.0000,N,07054.0000,W,0,0,180626,,,A"))
C("data_too_many_fields", "datafields", "field count per formatter", "serial",
  "REJECT/ignore - extra trailing commas",
  lambda: _ok("GPRMC,120000.00,A,4221.0000,N,07054.0000,W,0,0,180626,,,A,,,,"))
C("data_too_few_fields", "datafields", "field count per formatter", "serial",
  "REJECT/ignore - far too few fields",
  lambda: _ok("GPRMC,120000.00,A"))
C("data_nonnumeric", "datafields", "numeric fields numeric", "serial",
  "REJECT - letters where lat digits expected",
  lambda: _ok("GPRMC,120000.00,A,ABCD.EFGH,N,07054.0000,W,0,0,180626,,,A"))
C("data_out_of_range_lat", "datafields", "lat range", "serial",
  "REJECT/clamp - latitude 91 deg",
  lambda: _ok("GPRMC,120000.00,A,9100.0000,N,07054.0000,W,0,0,180626,,,A"))
C("data_invalid_time", "datafields", "time hhmmss.ss", "serial",
  "REJECT - time 99:99:99",
  lambda: _ok("GPRMC,999999.99,A,4221.0000,N,07054.0000,W,0,0,180626,,,A"))

# ====================== SENTENCE-SPECIFIC FIELD LIMITS ======================
C("len_ver_f4_over15", "fieldlimits", "VER field4 uid <=15", "serial",
  "REJECT/truncate - 20-char unique id",
  lambda: _ver(20, 10))
C("len_ver_f5_over32", "fieldlimits", "VER field5 data <=32", "serial",
  "REJECT/truncate - 40-char data field",
  lambda: _ver(10, 40))
C("len_smv_name_31", "fieldlimits", "SMV name <=30 (LISTENER truncates)", "serial",
  "ACCEPT+TRUNCATE to 30 - 31-char name",
  lambda: _smv_name(31))
C("len_smv_name_60", "fieldlimits", "SMV name <=30 (LISTENER truncates)", "serial",
  "ACCEPT+TRUNCATE to 30 - 60-char name",
  lambda: _smv_name(60))
C("len_smb_over58", "fieldlimits", "SMB <=58 chars", "serial",
  "REJECT/truncate - SMB field >58",
  lambda: _ok("GPSMB,1,1," + "Z"*70))

# ====================== AIVDM / AIVDO (transport-tagged, RF-reusable) ======================
C("ais_valid_single", "aivdm", "valid AIVDM single fragment", "aivdm",
  "no effect on sensor port (AIVDM not a sensor sentence) - reusable RF control",
  lambda: _aivdm(1, 1, None, "A", _AIVDM_PAYLOAD, 0))
C("ais_frag_claim2_send1", "aivdm", "fragment count matches parts sent", "aivdm",
  "REJECT - claims 2 fragments, only 1 sent",
  lambda: _aivdm(2, 1, 5, "A", _AIVDM_PAYLOAD, 0))
C("ais_frag_num_gt_count", "aivdm", "frag number <= frag count", "aivdm",
  "REJECT - fragment 3 of 2",
  lambda: _aivdm(2, 3, 5, "A", _AIVDM_PAYLOAD, 0))
C("ais_frag_count_zero", "aivdm", "fragment count >= 1", "aivdm",
  "REJECT - fragment count 0",
  lambda: _aivdm(0, 1, 5, "A", _AIVDM_PAYLOAD, 0))
C("ais_frag_num_zero", "aivdm", "fragment number >= 1", "aivdm",
  "REJECT - fragment number 0",
  lambda: _aivdm(2, 0, 5, "A", _AIVDM_PAYLOAD, 0))
C("ais_start_frag2", "aivdm", "multi-part starts at fragment 1", "aivdm",
  "REJECT - first fragment received is #2",
  lambda: _aivdm(2, 2, 5, "A", _AIVDM_PAYLOAD, 0))
C("ais_fill_bits_9", "aivdm", "fill bits 0-5", "aivdm",
  "REJECT - fill bits = 9 (max 5)",
  lambda: _aivdm(1, 1, None, "A", _AIVDM_PAYLOAD, 9))
C("ais_bad_channel", "aivdm", "channel A or B", "aivdm",
  "REJECT - channel 'X'",
  lambda: _aivdm(1, 1, None, "X", _AIVDM_PAYLOAD, 0))
C("ais_empty_channel", "aivdm", "channel field present", "aivdm",
  "REJECT/tolerate - empty channel field",
  lambda: _aivdm(1, 1, None, "", _AIVDM_PAYLOAD, 0))
C("ais_non6bit_payload", "aivdm", "payload is valid 6-bit ASCII", "aivdm",
  "REJECT - payload contains out-of-armor chars",
  lambda: _aivdm(1, 1, None, "A", "!!!\x7f\x7e@@", 0))
C("ais_vdo_vs_vdm", "aivdm", "AIVDO=own AIVDM=received", "aivdm",
  "no effect / record behavior - AIVDO injected on serial",
  lambda: _ok("AIVDO,1,1,,A," + _AIVDM_PAYLOAD + ",0"))

# ====================== PROPRIETARY ======================
C("prop_mfr_too_short", "proprietary", "$P + 3-char mfr ID", "serial",
  "REJECT - 2-char manufacturer id",
  lambda: _ok("PAB,data,data"))
C("prop_mfr_too_long", "proprietary", "$P + 3-char mfr ID", "serial",
  "REJECT - 4-char manufacturer id",
  lambda: _ok("PABCD,data,data"))
C("prop_mfr_lowercase", "proprietary", "mfr ID uppercase", "serial",
  "REJECT - lowercase manufacturer id",
  lambda: ("$Pabc,data,data*00\r\n").encode())

# ====================== QUERY ======================
C("query_wrong_identifier", "query", "query format $xxQQQ,...", "serial",
  "REJECT - query identifier not QQQ (QQX)",
  lambda: _ok("GPQQX,GP,RMC"))
C("query_bad_target_addr", "query", "5-char target address", "serial",
  "REJECT - 4-char target in query",
  lambda: _ok("CCQQQ,GPS,RMC"))

# ====================== ENCAPSULATION ======================
C("encap_unescaped_backslash", "encapsulation", "\\ is escape char", "serial",
  "REJECT - bare backslash in encapsulated data",
  lambda: ("!AIVDM,1,1,,A," + _AIVDM_PAYLOAD + "\\bad,0*00\r\n").encode())
C("encap_invalid_escape", "encapsulation", "valid escape sequences only", "serial",
  "REJECT - invalid escape \\q",
  lambda: ("!AIVDM,1,1,,A,\\q" + _AIVDM_PAYLOAD + ",0*00\r\n").encode())

# ====================== EDGE / NULL SENTENCES ======================
C("edge_empty_sentence", "edge", "non-empty sentence", "serial",
  "REJECT - just CRLF",
  lambda: CRLF)
C("edge_only_start", "edge", "sentence has content", "serial",
  "REJECT - only '$' then CRLF",
  lambda: b"$\r\n")
C("edge_only_delims", "edge", "sentence has content", "serial",
  "REJECT - only delimiters '$*\\r\\n'",
  lambda: b"$*\r\n")
C("edge_only_checksum", "edge", "sentence has body", "serial",
  "REJECT - '$*00' no body",
  lambda: b"$*00\r\n")


def get_cases(categories=None, ids=None):
    cs = CASES
    if categories:
        cs = [c for c in cs if c["category"] in categories]
    if ids:
        cs = [c for c in cs if c["id"] in ids]
    return cs


if __name__ == "__main__":
    # self-list
    from collections import Counter
    cats = Counter(c["category"] for c in CASES)
    print(f"{len(CASES)} cases across {len(cats)} categories:")
    for k, v in cats.items():
        print(f"  {k:14s} {v}")
