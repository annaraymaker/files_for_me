#!/usr/bin/env python3
"""Side-channel timing probe: tell whether an INDETERMINATE sentence is actually
*processed* by the unit, even when its content never appears in the AIS output.

IDEA
----
The conformance suite marks aivdm/encapsulation/proprietary/query sentences
INDETERMINATE: they carry no position, so a silent reject is indistinguishable
from "ignored as irrelevant" - we see nothing in the output. But *processing*
input costs time, and if the unit parses a sentence (vs. dropping it at the wire)
that cost can perturb the timing of the position output stream.

We can't measure parse cost directly, so we BRACKET it. For each probe sentence we
compare its output-perturbation against two controls injected at matched byte volume:

  garbage   : random non-$ bytes -> dropped at framing  -> LOWER bound (wire load only)
  validgps  : extra valid GPS sentences -> fully parsed+emitted -> UPPER bound
  probe     : the INDETERMINATE sentence -> sits somewhere between

If probe ~= garbage  -> not parsed beyond framing (dropped early)
If probe ~= validgps -> fully parsed (processed, just not emitted as position)
If probe is between  -> partially parsed

We run many alternating trials and compare distributions nonparametrically, so the
verdict is statistical, not a single-shot guess. The garbage arm subtracts out the
pure wire-time cost (one shared 4800-baud line), isolating *processing* cost.

PROTOCOL (per trial)
--------------------
  baseline_s : inject valid GPS at 1 Hz, record output cadence (the control window)
  burst      : pause GPS, inject the arm payload (probe / garbage / validgps) as one
               burst of `dose` copies, record output
  recovery_s : resume valid GPS at 1 Hz, record output until cadence recovers
Trials alternate arms so slow drift cancels. Per trial we measure the output
DISRUPTION (max output gap and time-to-recover-cadence) around the burst.

USAGE
-----
  python3 run_sidechannel.py --gps /dev/ttyUSB0 --ais /dev/ttyUSB1 --vendor Furuno \
      [--targets ais_frag_count_bad,prop_unknown_mfr,qry_unknown] \
      [--doses 1,10,100] [--trials 16] [--baseline-s 25] [--recovery-s 35] [--dry-run]

Defaults pick one representative INDETERMINATE case per type. Time cost is printed
up front (it is large by design - this is a statistical experiment).
"""
import argparse
import json
import os
import random
import time
from datetime import datetime, timezone

import nmea
from capture import CaptureThread

try:
    import serial
    HAVE_SERIAL = True
except Exception:
    HAVE_SERIAL = False

BASE_LAT, BASE_LON = 42.35, -70.90      # same baseline as the conformance suite
GPS_BAUD = 4800
AIS_BAUD = 38400


def utcstamp():
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def open_serial(port, baud, dry):
    if dry or not HAVE_SERIAL:
        return None
    return serial.Serial(port, baud, timeout=0.2)


def emit(ser, dry, data, evlog, tag):
    if isinstance(data, str):
        data = data.encode()
    if not dry and ser is not None:
        ser.write(data)
        ser.flush()
    if evlog is not None:
        evlog.append({"t": time.time(), "event": "tx", "tag": tag, "nbytes": len(data)})


def gps_line(lat=BASE_LAT, lon=BASE_LON, sog=12.0, cog=90.0):
    # the proven 3-sentence batch the units accept (GGA/RMC/VTG); full_batch returns
    # a list of sentence strings, each already CRLF-terminated
    return "".join(nmea.full_batch(lat, lon, sog=sog, cog=cog)).encode()


def inject_gps_for(ser, dry, seconds, evlog, rate=1.0):
    """Inject valid baseline GPS at `rate` Hz for `seconds` (the cadence reference)."""
    n = max(1, int(seconds * rate))
    period = 1.0 / rate
    for _ in range(n):
        emit(ser, dry, gps_line(), evlog, "gps")
        if not dry:
            time.sleep(period)


# ---- arm payloads (matched by total byte volume to the probe) ----
def probe_payload(sentence_bytes, dose):
    return sentence_bytes * dose


def garbage_payload(nbytes):
    """Random printable bytes with NO '$'/'!'/CR/LF, so the unit drops them at framing.
    Matched to the probe's total byte count -> isolates wire-time from parse-time."""
    alphabet = bytes(c for c in range(0x20, 0x7F) if chr(c) not in "$!*\r\n")
    return bytes(random.choice(alphabet) for _ in range(nbytes))


def validgps_payload(nbytes):
    """Valid GPS sentences (fully parsed + emitted) totalling ~nbytes -> upper bound."""
    out = b""
    i = 0
    while len(out) < nbytes:
        # vary position slightly so they're all valid, distinct, plausible
        out += nmea.rmc(BASE_LAT + (i % 5) * 0.001, BASE_LON, sog=12.0, cog=90.0).encode()
        i += 1
    return out


def run_trial(gps_ser, dry, arm, payload, baseline_s, recovery_s, evlog, target, dose, trial):
    evlog.append({"t": time.time(), "event": "trial_start", "arm": arm,
                  "target": target, "dose": dose, "trial": trial})
    # 1) baseline cadence reference
    evlog.append({"t": time.time(), "event": "phase", "phase": "baseline", "arm": arm,
                  "target": target, "dose": dose, "trial": trial})
    inject_gps_for(gps_ser, dry, baseline_s, evlog)
    # 2) burst (GPS paused) - the perturbation
    evlog.append({"t": time.time(), "event": "burst_start", "arm": arm,
                  "target": target, "dose": dose, "trial": trial,
                  "burst_bytes": len(payload),
                  "predicted_wire_s": round(len(payload) * 10.0 / GPS_BAUD, 3)})
    emit(gps_ser, dry, payload, evlog, f"burst:{arm}")
    evlog.append({"t": time.time(), "event": "burst_end", "arm": arm,
                  "target": target, "dose": dose, "trial": trial})
    # 3) recovery
    evlog.append({"t": time.time(), "event": "phase", "phase": "recovery", "arm": arm,
                  "target": target, "dose": dose, "trial": trial})
    inject_gps_for(gps_ser, dry, recovery_s, evlog)
    evlog.append({"t": time.time(), "event": "trial_end", "arm": arm,
                  "target": target, "dose": dose, "trial": trial})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gps", default="/dev/ttyUSB0")
    ap.add_argument("--ais", default="/dev/ttyUSB1")
    ap.add_argument("--vendor", default="unknown")
    ap.add_argument("--targets", default=None,
                    help="comma-sep conformance case ids to probe (default: representative set)")
    ap.add_argument("--doses", default="1,10,100",
                    help="comma-sep repetition counts for the burst")
    ap.add_argument("--trials", type=int, default=16,
                    help="trials PER (target,dose,arm); more = more statistical power")
    ap.add_argument("--baseline-s", type=float, default=25.0)
    ap.add_argument("--recovery-s", type=float, default=35.0)
    ap.add_argument("--outdir", default="results")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    import conformance_cases as cc
    by_id = {c["id"]: c for c in cc.CASES}

    # default targets: one representative INDETERMINATE-prone case per non-position type
    if args.targets:
        target_ids = [t.strip() for t in args.targets.split(",") if t.strip()]
    else:
        prefer = ["ais_frag_num_gt_count", "ais_non6bit_payload", "encap_unescaped_backslash",
                  "prop_mfr_too_long", "query_wrong_identifier"]
        target_ids = [t for t in prefer if t in by_id][:3]
        if not target_ids:  # fallback: any aivdm/proprietary/query case
            for c in cc.CASES:
                if c["category"] in ("aivdm", "proprietary", "query") and c["id"] not in target_ids:
                    target_ids.append(c["id"])
                if len(target_ids) >= 3:
                    break

    doses = [int(d) for d in args.doses.split(",")]
    arms = ["probe", "garbage", "validgps"]

    # time estimate
    per_trial = args.baseline_s + args.recovery_s + 5
    total_trials = len(target_ids) * len(doses) * len(arms) * args.trials
    est_min = total_trials * per_trial / 60.0
    print(f"side-channel probe: vendor={args.vendor}")
    print(f"targets={target_ids}")
    print(f"doses={doses}  arms={arms}  trials={args.trials}")
    print(f"=> {total_trials} trials, ~{est_min:.0f} min "
          f"({est_min/60:.1f} h). Run under tmux.")
    if args.dry_run:
        print("(dry-run: no serial I/O; structure check only)")

    rundir = os.path.join(args.outdir, f"sidechannel_{args.vendor}__{utcstamp()}")
    os.makedirs(rundir, exist_ok=True)
    cap_path = os.path.join(rundir, "capture.jsonl")
    ev_path = os.path.join(rundir, "events.jsonl")

    cap_thread = None
    if not args.dry_run and HAVE_SERIAL:
        cap_thread = CaptureThread(args.ais, AIS_BAUD, cap_path, node=args.vendor)
        cap_thread.start()
    gps_ser = open_serial(args.gps, GPS_BAUD, args.dry_run)

    evlog = []
    meta = {"experiment": "sidechannel", "vendor": args.vendor,
            "targets": target_ids, "doses": doses, "arms": arms,
            "trials": args.trials, "baseline_s": args.baseline_s,
            "recovery_s": args.recovery_s, "gps_baud": GPS_BAUD,
            "start_t": time.time(), "start_utc": utcstamp()}
    json.dump(meta, open(os.path.join(rundir, "metadata.json"), "w"), indent=2)

    try:
        # settle
        if not args.dry_run:
            print("settling (120s)...")
            inject_gps_for(gps_ser, args.dry_run, 120, evlog)
        for target in target_ids:
            sentence_bytes = by_id[target]["gen"]()
            if isinstance(sentence_bytes, list):  # skip sequence cases
                continue
            for dose in doses:
                nbytes = len(sentence_bytes) * dose
                # interleave arms across trials so drift cancels (probe,garbage,validgps,...)
                for trial in range(args.trials):
                    for arm in arms:
                        if arm == "probe":
                            payload = probe_payload(sentence_bytes, dose)
                        elif arm == "garbage":
                            payload = garbage_payload(nbytes)
                        else:
                            payload = validgps_payload(nbytes)
                        run_trial(gps_ser, args.dry_run, arm, payload,
                                  args.baseline_s, args.recovery_s, evlog,
                                  target, dose, trial)
                        # flush events periodically
                        with open(ev_path, "w") as f:
                            for e in evlog:
                                f.write(json.dumps(e) + "\n")
                print(f"  done target={target} dose={dose}")
    finally:
        with open(ev_path, "w") as f:
            for e in evlog:
                f.write(json.dumps(e) + "\n")
        if cap_thread:
            cap_thread.stop()
        if gps_ser:
            gps_ser.close()
    print(f"\nwrote {rundir}")
    print(f"analyze: python3 analyze_sidechannel.py {rundir}")


if __name__ == "__main__":
    main()
