#!/usr/bin/env python3
"""Run one solo experiment, recording everything in a self-contained folder.

For each run it creates:  results/<expid>__<UTC timestamp>/
    metadata.json   what was run, ports, params, manual config, start/end
    capture.jsonl   raw timestamped AIS output (ground truth)
    events.jsonl    markers: injection start/stop, each jump, each malformation
    summary.json    written by analyze.py after the run

Usage:
    python3 run.py ghost_static --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
    python3 run.py malformed_nmea --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
    python3 run.py impossible_jump --gps ... --ais ... --dry-run   # no hardware

The AIS port is whatever you want to treat as the "receiver": the spoofed
transponder's own output (VDO) or a second transponder receiving over air (VDM).
"""
import argparse, json, os, time, sys
from datetime import datetime, timezone

import serial
import inject
from capture import CaptureThread
from experiments import EXPERIMENTS


def log_event(path, d):
    d = {"t": time.time(), **d}
    with open(path, "a", buffering=1) as f:
        f.write(json.dumps(d) + "\n")


def run(expid, gps_port, ais_port, gps_baud, ais_baud, dry):
    if expid not in EXPERIMENTS:
        sys.exit(f"unknown experiment '{expid}'. choices: {list(EXPERIMENTS)}")
    exp = EXPERIMENTS[expid]
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    rundir = os.path.join(os.path.dirname(__file__), "results", f"{expid}__{stamp}")
    os.makedirs(rundir, exist_ok=True)
    cap_path = os.path.join(rundir, "capture.jsonl")
    ev_path = os.path.join(rundir, "events.jsonl")

    # ----- manual config gate -----
    if exp.get("manual_config"):
        mc = exp["manual_config"]
        print("\n*** MANUAL STEP REQUIRED ***")
        print(f"  Set the transponder MMSI to: {mc['mmsi']}")
        print(f"  Reason: {mc['why']}")
        if not dry:
            input("  Press ENTER once the unit is configured and transmitting... ")

    meta = {
        "experiment": expid,
        "desc": exp["desc"],
        "notes": exp["notes"],
        "manual_config": exp.get("manual_config"),
        "action": exp["action"],
        "expect": exp["expect"],
        "gps_port": gps_port, "ais_port": ais_port,
        "gps_baud": gps_baud, "ais_baud": ais_baud,
        "dry_run": dry,
        "start_utc": datetime.now(timezone.utc).isoformat(),
        "start_t": time.time(),
    }

    # ----- start capture -----
    cap = CaptureThread(ais_port, ais_baud, cap_path, node="rx")
    if not dry:
        cap.start()
        time.sleep(1.0)  # let it open the port
    print(f"\n[{expid}] recording -> {rundir}")

    gps = None if dry else serial.Serial(gps_port, gps_baud, timeout=1)
    ev = lambda d: log_event(ev_path, d)
    act = exp["action"]
    mode = act["mode"]

    try:
        ev({"event": "inject_start", "mode": mode})
        if mode == "static":
            inject.run_static(gps, dry, act["lat"], act["lon"], act["dur"], events=ev)
        elif mode == "jump":
            inject.run_jump(gps, dry, act["a"], act["b"], act["dur"], act["hold"], events=ev)
        elif mode == "move":
            inject.run_move(gps, dry, act["lat"], act["lon"], act["sog"], act["cog"], act["dur"], events=ev)
        elif mode == "malformed":
            inject.run_malformed(gps, dry, act.get("gap", 3), events=ev, repeat=act.get("repeat", 1))
        elif mode == "sweep":
            inject.run_sweep(gps, dry, [tuple(p) for p in act["positions"]],
                             act.get("hold", 20), events=ev)
        ev({"event": "inject_stop", "mode": mode})

        # disappearance: keep capturing in silence to catch cessation/alarm
        if act.get("silence"):
            ev({"event": "silence_start", "seconds": act["silence"]})
            print(f"  injection stopped; observing silence for {act['silence']}s...")
            if not dry:
                time.sleep(act["silence"])
            ev({"event": "silence_end"})
    finally:
        if gps:
            gps.close()
        meta["end_utc"] = datetime.now(timezone.utc).isoformat()
        meta["end_t"] = time.time()
        if not dry:
            time.sleep(1.0)
            cap.stop(); cap.join(timeout=3)
            meta["captured_lines"] = cap.lines
        with open(os.path.join(rundir, "metadata.json"), "w") as f:
            json.dump(meta, f, indent=2)
    print(f"[{expid}] done. {meta.get('captured_lines','(dry)')} lines captured.")
    print(f"  analyze with: python3 analyze.py {rundir}")
    return rundir


def main():
    p = argparse.ArgumentParser()
    p.add_argument("experiment", help=f"one of: {list(EXPERIMENTS)}")
    p.add_argument("--gps", default="/dev/ttyUSB0", help="sensor/GPS-in port")
    p.add_argument("--ais", default="/dev/ttyUSB1", help="AIS-out port to record")
    p.add_argument("--gps-baud", type=int, default=4800)
    p.add_argument("--ais-baud", type=int, default=38400)
    p.add_argument("--dry-run", action="store_true", help="no serial, just exercise logic")
    a = p.parse_args()
    run(a.experiment, a.gps, a.ais, a.gps_baud, a.ais_baud, a.dry_run)


if __name__ == "__main__":
    main()
