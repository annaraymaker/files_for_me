#!/usr/bin/env python3
"""Analyze a side-channel timing run. For each (target, dose) we compare the output
DISRUPTION caused by the probe burst against two controls injected at matched byte
volume: garbage (dropped at framing = wire-only lower bound) and validgps (fully
parsed+emitted = upper bound). A probe that disrupts output significantly MORE than
garbage is being processed past the framing layer, even though its content never
appears as a position. We use a nonparametric Mann-Whitney U test (robust to timing
jitter) and also report where the probe sits between the two controls.

per-trial metric: the output DISRUPTION around the burst =
   max gap between consecutive AIS outputs in [burst_start, burst_start + window]
   minus the unit's own baseline inter-output interval for that trial.
This isolates the *extra* silence the burst caused, normalized per trial.

verdict per (target, dose):
  PROCESSED        : probe disruption > garbage (stat. sig.) -> parsed past framing
  NOT-OBSERVABLE   : probe ~ garbage (no extra disruption beyond wire load)
  (and a 0..1 "parse fraction" locating probe between garbage[0] and validgps[1])
"""
import json
import os
import sys
import statistics
from collections import defaultdict


def load(p):
    out = []
    if os.path.exists(p):
        for line in open(p):
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except Exception:
                    pass
    return out


def out_times(cap):
    """Timestamps of AIS output lines (any decodable/transmitted line)."""
    ts = []
    for c in cap:
        raw = c.get("raw", "")
        if raw.startswith("!AIV") or raw.startswith("$"):
            ts.append(c.get("t"))
    return sorted(t for t in ts if t is not None)


def mann_whitney_u(a, b):
    """Two-sided Mann-Whitney U with normal approximation. Returns (U, z, p, dir).
    Nonparametric: robust to the heavy-tailed jitter in serial timing. No SciPy dep."""
    na, nb = len(a), len(b)
    if na == 0 or nb == 0:
        return None, None, None, None
    combined = sorted([(v, 0) for v in a] + [(v, 1) for v in b])
    # rank with ties (average ranks)
    ranks = [0.0] * len(combined)
    i = 0
    while i < len(combined):
        j = i
        while j + 1 < len(combined) and combined[j + 1][0] == combined[i][0]:
            j += 1
        avg = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            ranks[k] = avg
        i = j + 1
    ra = sum(ranks[k] for k in range(len(combined)) if combined[k][1] == 0)
    ua = ra - na * (na + 1) / 2.0
    ub = na * nb - ua
    u = min(ua, ub)
    mu = na * nb / 2.0
    sigma = (na * nb * (na + nb + 1) / 12.0) ** 0.5
    if sigma == 0:
        return u, 0.0, 1.0, "none"
    z = (u - mu) / sigma
    # two-sided p from normal approx
    import math
    p = 2.0 * (1.0 - 0.5 * (1.0 + math.erf(abs(z) / (2 ** 0.5))))
    direction = "a>b" if (sum(a) / na) > (sum(b) / nb) else "a<b"
    return u, z, p, direction


def trial_disruption(events, cap, target, dose, arm, trial):
    """Extra output silence the burst caused = max output gap in the burst+recovery
    window minus the trial's own baseline median inter-output interval."""
    # find this trial's phase boundaries
    bstart = bend = base_start = trial_end = None
    for e in events:
        if e.get("target") == target and e.get("dose") == dose and \
           e.get("arm") == arm and e.get("trial") == trial:
            ev = e.get("event")
            if ev == "phase" and e.get("phase") == "baseline":
                base_start = e["t"]
            elif ev == "burst_start":
                bstart = e["t"]
            elif ev == "burst_end":
                bend = e["t"]
            elif ev == "trial_end":
                trial_end = e["t"]
    if None in (bstart, base_start, trial_end):
        return None
    ot = out_times(cap)
    # baseline cadence for THIS trial (outputs between baseline start and burst)
    base_out = [t for t in ot if base_start <= t < bstart]
    base_intervals = [base_out[i + 1] - base_out[i] for i in range(len(base_out) - 1)]
    base_med = statistics.median(base_intervals) if base_intervals else None
    # disruption window: burst start to trial end
    win_out = [t for t in ot if bstart <= t <= trial_end]
    edges = [bstart] + win_out + [trial_end]
    max_gap = max(edges[i + 1] - edges[i] for i in range(len(edges) - 1)) if len(edges) >= 2 else 0.0
    if base_med is None:
        return max_gap
    return max(0.0, max_gap - base_med)   # extra silence beyond normal cadence


def main():
    if len(sys.argv) < 2:
        sys.exit("usage: python3 analyze_sidechannel.py results/<sidechannel_dir>")
    rundir = sys.argv[1]
    meta = json.load(open(os.path.join(rundir, "metadata.json")))
    events = load(os.path.join(rundir, "events.jsonl"))
    cap = load(os.path.join(rundir, "capture.jsonl"))
    vendor = meta.get("vendor", "?")

    targets = meta["targets"]; doses = meta["doses"]
    arms = meta.get("arms", ["probe", "garbage", "validgps"])
    trials = meta["trials"]

    print(f"\n=== side-channel timing probe: {vendor} ===")
    print(f"targets={targets} doses={doses} trials/arm={trials}")
    print("metric = extra output silence caused by the burst (s), per trial\n")

    summary = []
    for target in targets:
        for dose in doses:
            byarm = {}
            for arm in arms:
                vals = []
                for tr in range(trials):
                    d = trial_disruption(events, cap, target, dose, arm, tr)
                    if d is not None:
                        vals.append(d)
                byarm[arm] = vals
            if not all(byarm.get(a) for a in arms):
                continue

            def med(x):
                return statistics.median(x) if x else float("nan")
            g_med = med(byarm["garbage"]); v_med = med(byarm["validgps"])
            p_med = med(byarm["probe"])
            # stat test: probe vs garbage (is probe disrupting MORE than wire-only?)
            u, z, pval, direction = mann_whitney_u(byarm["probe"], byarm["garbage"])
            processed = (pval is not None and pval < 0.05 and direction == "a>b")
            # where does probe sit between garbage(0) and validgps(1)?
            span = v_med - g_med
            frac = ((p_med - g_med) / span) if span > 1e-6 else float("nan")

            verdict = ("PROCESSED (disrupts more than wire-only garbage)"
                       if processed else
                       "no observable side channel (probe ~ garbage)")
            print(f"target={target}  dose={dose}")
            print(f"  median extra-silence:  garbage={g_med:.2f}s  "
                  f"probe={p_med:.2f}s  validgps={v_med:.2f}s")
            print(f"  probe vs garbage: p={pval:.4f} ({direction})  -> {verdict}")
            if span > 1e-6 and not (frac != frac):
                where = ("near garbage/dropped" if frac < 0.33 else
                         "near validgps/fully-parsed" if frac > 0.66 else
                         "between (partial parse)")
                print(f"  parse-depth fraction: {frac:.2f} (0=dropped,1=full) -> {where}")
            print()
            summary.append({"target": target, "dose": dose,
                            "garbage_med": g_med, "probe_med": p_med,
                            "validgps_med": v_med, "p_probe_vs_garbage": pval,
                            "direction": direction, "processed": bool(processed),
                            "parse_fraction": frac})

    # dose-response note
    print("dose-response: look for probe extra-silence rising with dose (accumulation)")
    json.dump({"vendor": vendor, "results": summary},
              open(os.path.join(rundir, "summary_sidechannel.json"), "w"), indent=2)
    print(f"\nwrote {os.path.join(rundir, 'summary_sidechannel.json')}")


if __name__ == "__main__":
    main()
