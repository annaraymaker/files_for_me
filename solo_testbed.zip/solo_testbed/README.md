# Solo AIS Experiment Harness

Runs the six **solo** AIS experiments (no SDR / HackRF needed) on a single
Raspberry Pi with one transponder: GPS injection in, AIS capture out, with
every run recorded in a self-contained folder for later analysis.

The six experiments:
1. `ghost_static`        - fake a static position (default: on land, impossible)
2. `ghost_sweep`         - several positions across plausibility classes
3. `impossible_coords`   - sweep literally out-of-range lat/lon values
4. `impossible_jump`     - teleport between two far-apart positions
5. `fake_identity_class` - transmit under a SAR-aircraft MMSI prefix
6. `fake_epirb_location` - EPIRB-AIS identity at a chosen location
7. `disappearance`       - transmit, then stop; watch for target-lost
8. `malformed_nmea`      - feed broken NMEA (bad structure) to the sensor input

DoS / parser-stress experiments (analyzed with analyze_dos.py):
9.  `parser_length_sweep` - suppression vs oversized line length
10. `unterminated_hold`   - bytes with no terminator; does the parser stall?
11. `flood_dos`           - saturate the channel; sustained suppression + recovery
12. `alert_trigger`       - which inputs raise AIS alerts, and can they be sustained

---

## 1. What's in this folder
| File | Purpose |
|------|---------|
| `run.py`         | Run one experiment, record everything |
| `analyze.py`     | Decode a finished run, print PASS/REVIEW, write summary.json |
| `experiments.py` | The six experiments as DATA (edit coords / MMSIs here) |
| `inject.py`      | GPS injector: static / jump / move / malformed |
| `capture.py`     | Logs the AIS output port to timestamped JSONL |
| `nmea.py`        | Builds valid NMEA + the malformed-NMEA library |
| `gps_sim.py`     | Standalone GPS simulator (general injection / manual tests) |
| `requirements.txt` | Python dependencies |
| `setup.sh`       | One-time dependency install |
| `results/`       | One folder is created here per run |

The NMEA sent is exactly GGA/RMC/VTG - the same set proven to work on all three
transponders.

---

## 2. Install (one time, on the Pi)
Copy this folder to the Pi, then:
```bash
cd solo_testbed
./setup.sh
```
That runs `pip install -r requirements.txt --break-system-packages`
(pyserial + pyais). If `./setup.sh` won't execute, run that pip line directly.

---

## 3. Wire the transponder under test
Two USB-RS422 adapters on the Pi, one per direction:

| Direction | From / To | Baud |
|-----------|-----------|------|
| **GPS in**  | Pi adapter T/R pair -> transponder SENSOR port (RD / H-C) | 4800 |
| **AIS out** | transponder DISPLAY/ECDIS port (TD pair) -> Pi adapter RX pair | 38400 |

Tie grounds (GND <-> COMMON / SG) on both. If a direction shows nothing, swap
the A/B (+/-) wires of that pair - harmless, fixes reversed polarity.

---

## 4. Find your serial ports
```bash
ls /dev/serial/by-id/      # stable names (preferred)
ls /dev/ttyUSB*            # quick check
```
Work out which port is GPS-in and which is AIS-out (run something, watch the
adapter's TX/RX LED, or unplug-and-recheck). Example used below:
GPS-in = `/dev/ttyUSB0`, AIS-out = `/dev/ttyUSB1`.

If a port is "busy", free it first:
```bash
sudo systemctl stop gpsd ModemManager 2>/dev/null
```

---

## 5. IMPORTANT: set the transponder identity FIRST
On the unit's own menu, set the MMSI / ship data **before** running - a
transponder will not validate an injected position until it has a valid
identity. For the two identity experiments the runner prints the exact MMSI to
set and waits for you to press ENTER.

---

## 6. Run an experiment
General form:
```bash
python3 run.py <experiment> --gps <gps_port> --ais <ais_port>
```
The six:
```bash
python3 run.py ghost_static        --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
python3 run.py ghost_sweep          --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
python3 run.py impossible_coords    --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
python3 run.py impossible_jump     --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
python3 run.py fake_identity_class --gps /dev/ttyUSB0 --ais /dev/ttyUSB1   # prompts for MMSI
python3 run.py fake_epirb_location --gps /dev/ttyUSB0 --ais /dev/ttyUSB1   # prompts for MMSI
python3 run.py disappearance       --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
python3 run.py malformed_nmea      --gps /dev/ttyUSB0 --ais /dev/ttyUSB1

# DoS / parser-stress (these establish a valid GPS baseline first, then attack):
python3 run.py parser_length_sweep --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
python3 run.py unterminated_hold   --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
python3 run.py flood_dos           --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
python3 run.py alert_trigger       --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
```

The DoS/alert experiments print `analyze with: python3 analyze_dos.py <dir>` -
use that analyzer (not analyze.py). It classifies the output over time as
valid-fix / no-fix(91,181) / alert and reports, per attack, how long legitimate
reporting was suppressed (suppression_s) vs the raw transmit time (predicted_s).
Reading: suppression ~= predicted means no max-length enforcement (DoS scales
with line size); suppression >> predicted means a parser stall (worse bug);
never going no-fix means the unit absorbed that input with no DoS.
Options:
- `--dry-run`  : no hardware; prints the sentences so you can see what it does
- `--gps-baud` : default 4800
- `--ais-baud` : default 38400

Tip: run long experiments inside `tmux` so an SSH disconnect won't kill them.

The `--ais` port can be the spoofed unit's **own** output (simplest - logs what
it transmits, VDO) or a **second** transponder receiving over air (VDM, the
truer "receiver" view). Either works; own-output is the easy default.

---

## 7. Analyze a run
Each run prints the folder it created, e.g.
`results/ghost_static__20260617T140312Z`. Analyze it:
```bash
python3 analyze.py results/ghost_static__20260617T140312Z
```
Prints a PASS/REVIEW verdict per check and writes `summary.json` into the folder.

---

## 8. What every run records (results/<experiment>__<UTC>/)
| File | Contents |
|------|----------|
| `metadata.json` | experiment, ports, params, manual config, start/end times |
| `capture.jsonl` | raw timestamped AIS output - ground truth, never decoded live |
| `events.jsonl`  | markers: inject start/stop, each jump, each malformation |
| `summary.json`  | analyzer verdict (after you run analyze.py) |

Raw capture + timestamps means you can re-analyze later without re-running.

---

## 9. Per-experiment notes
- **ghost_static / ghost_sweep / impossible_coords** are three different tests,
  don't confuse them: `ghost_static` and `ghost_sweep` use *valid* coordinates
  at implausible *places* (on land, poles, Null Island - tests geographic
  plausibility); `impossible_coords` uses literally *out-of-range values*
  (lat>90, lon>180, minutes>=60, bad hemispheres - tests input validation);
  `malformed_nmea` breaks the *sentence structure* itself. Note that for
  impossible_coords the transponder re-encodes position before transmitting, so
  it mainly shows how each *unit* validates bad GPS input; check summary.json's
  `distinct_positions_transmitted` to see what it actually sent (clamped? the
  91/181 no-fix sentinel? ignored?). Receiver-side out-of-range handling is an
  SDR-phase experiment.
- **fake_identity_class / fake_epirb_location**: code can't set MMSI (menu +
  password). Runner prints the MMSI to set and waits. The intended MMSI is saved
  in metadata.json so the manual step is documented.
- **disappearance**: after injection stops, capture keeps running for a silence
  window to catch cessation. Whether the *receiver alarms* "lost target" is a
  chartplotter behavior - watch OpenCPN, or capture ALR sentences.
- **malformed_nmea**: a PASS only means output didn't vanish. The real finding
  is in capture.jsonl - look for resets, garbage, or the unit *accepting* bad
  data. events.jsonl timestamps each malformation so you can line up any
  misbehavior to its cause.

---

## 10. Running across all three transponders
Rewire the two adapters to the next unit (or use different ttyUSB ports if all
three are wired at once) and rerun the same commands. Each run timestamps its
own folder, so nothing is overwritten. Set each unit's identity first.

---

## 11. Editing experiments
All six are plain data in `experiments.py` - change coordinates, MMSIs,
durations, jump distance, malformation spacing there. No need to touch the
runner. Keep MMSIs in the TEST / reserved-pattern ranges so nothing resembles a
real vessel.

---

## 12. Standalone GPS simulator
`gps_sim.py` is the general-purpose injector (static / move / waypoints) for
manual testing outside the experiment framework:
```bash
python3 gps_sim.py --port /dev/ttyUSB0 --baud 4800 static 42.35 -70.90
python3 gps_sim.py --port /dev/ttyUSB0 --baud 4800 move 42.35 -70.90 --speed 8 --course 90
```


---

## 13. Spec-conformance suite (run-once, ~1 hr/vendor)
A separate, comprehensive harness that tests IEC 61162-1 / NMEA 0183 sentence-
structure rules: 72 cases across structure, checksum, characters, reserved chars,
address field, data fields, sentence-specific field limits (VER/SMV/SMB), AIVDM,
proprietary, query, encapsulation, and edge cases. Files: `conformance_cases.py`
(cases as data), `run_conformance.py` (runner), `analyze_conformance.py` (analyzer).

Run it:
```bash
python3 run_conformance.py --gps /dev/ttyUSB0 --ais /dev/ttyUSB1 --vendor furuno
```
- holds a CONTINUOUS valid baseline; injects each malformed case as a perturbation
- control sentence every 5 cases (a later control failing = unit wedged there)
- `--gap 50` quiet seconds around each case (>= the ~30s reacquisition latency)
- `--categories checksum,address` to run a subset; `--ids cks_missing,...` for specific
- `--resume` to continue an interrupted run; `--dry-run` for no hardware
- ~72 cases x ~50s ~= 1 hr/vendor; run in tmux

Analyze:
```bash
python3 analyze_conformance.py results/conformance_furuno__<ts>
```
Classifies each case five ways: REJECTED (stayed on baseline - usually conformant),
ACCEPTED (output changed to reflect bad input - the security-relevant violation),
DEGRADED (went no-fix/dropped), ALERTED ($AIALC/ALR/PFEC overlay), ANOMALOUS.
For address/aivdm/proprietary/query/encap, REJECTED may mean "ignored as
irrelevant" rather than "validated+rejected" - flagged per case.

AIVDM cases are tagged transport="aivdm" and use stable ids so the SDR/RF phase
can replay the IDENTICAL bytes - giving a serial-vs-RF parser comparison per case.

---

## 14. Conformance harness robustness (v2 - audited)
The conformance suite was audited and hardened after an early bug (over-length
cases that were not actually over-length). Fixes baked in:
- **76 cases** (was 72): over-length boundary expanded to a real sub-sweep
  (83, 90, 120, 200, 500, 1000 chars) bridging the 82-char limit and the ~2KB
  DoS knee. Each over-length case is verified to be EXACTLY its stated length.
- **Acceptance is now detectable.** Every position-bearing malformed case carries
  a DISTINCT spoof position (43.5N/71.5W) while valid baseline GPS (42.35/-70.90)
  flows between cases. If a unit ACCEPTS a malformed sentence its output jumps to
  the spoof position -> scored ACCEPTED. Previously these reused the baseline, so
  acceptance was invisible (the bug that hid the over-length issue).
- **No checksum confound.** Cases testing control/reserved/escape characters now
  carry a VALID checksum over the malformed body, so the only anomaly is the
  feature under test (not a bad checksum the unit would reject first).
- **Analyzer**: reassembles multi-fragment AIVDM/AIVDO (routine Type 5 no longer
  mis-flagged ANOMALOUS); alert counts measured as excess over the steady-state
  baseline chatter rate (chatty units like DY emit alerts constantly).
- Controls remain at the baseline position and must show a valid fix; a failed
  later control marks where the unit wedged.

Re-run the full suite per vendor after any case-library change; the over-length
and acceptance-detection fixes mean earlier conformance runs should be re-done.
