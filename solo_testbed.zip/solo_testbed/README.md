# Solo AIS Experiment Harness

Runs the six **solo** AIS experiments (no SDR / HackRF needed) on a single
Raspberry Pi with one transponder: GPS injection in, AIS capture out, with
every run recorded in a self-contained folder for later analysis.

The six experiments:
1. `ghost_static`        - fake a static position (default: on land, impossible)
2. `ghost_sweep`         - several positions across plausibility classes
3. `impossible_jump`     - teleport between two far-apart positions
4. `fake_identity_class` - transmit under a SAR-aircraft MMSI prefix
5. `fake_epirb_location` - EPIRB-AIS identity at a chosen location
6. `disappearance`       - transmit, then stop; watch for target-lost
7. `malformed_nmea`      - feed broken NMEA to the sensor input

---

## 1. What's in this folder
| File | Purpose |
|------|---------|
| `run.py`         | Run one experiment, record everything |
| `analyze.py`     | Decode a finished run, print PASS/REVIEW, write summary.json |
| `experiments.py` | The six experiments as DATA (edit coords / MMSIs here) |
| `inject.py`      | GPS injector: static / jump / move / malformed |
| `capture.py`     | Logs the AIS output port to timestamped JSONL |
| `nmea.py`        | Builds valid NMEA + the malformed-NMEA library |
| `gps_sim.py`     | Standalone GPS simulator (general injection / manual tests) |
| `requirements.txt` | Python dependencies |
| `setup.sh`       | One-time dependency install |
| `results/`       | One folder is created here per run |

The NMEA sent is exactly GGA/RMC/VTG - the same set proven to work on all three
transponders.

---

## 2. Install (one time, on the Pi)
Copy this folder to the Pi, then:
```bash
cd solo_testbed
./setup.sh
```
That runs `pip install -r requirements.txt --break-system-packages`
(pyserial + pyais). If `./setup.sh` won't execute, run that pip line directly.

---

## 3. Wire the transponder under test
Two USB-RS422 adapters on the Pi, one per direction:

| Direction | From / To | Baud |
|-----------|-----------|------|
| **GPS in**  | Pi adapter T/R pair -> transponder SENSOR port (RD / H-C) | 4800 |
| **AIS out** | transponder DISPLAY/ECDIS port (TD pair) -> Pi adapter RX pair | 38400 |

Tie grounds (GND <-> COMMON / SG) on both. If a direction shows nothing, swap
the A/B (+/-) wires of that pair - harmless, fixes reversed polarity.

---

## 4. Find your serial ports
```bash
ls /dev/serial/by-id/      # stable names (preferred)
ls /dev/ttyUSB*            # quick check
```
Work out which port is GPS-in and which is AIS-out (run something, watch the
adapter's TX/RX LED, or unplug-and-recheck). Example used below:
GPS-in = `/dev/ttyUSB0`, AIS-out = `/dev/ttyUSB1`.

If a port is "busy", free it first:
```bash
sudo systemctl stop gpsd ModemManager 2>/dev/null
```

---

## 5. IMPORTANT: set the transponder identity FIRST
On the unit's own menu, set the MMSI / ship data **before** running - a
transponder will not validate an injected position until it has a valid
identity. For the two identity experiments the runner prints the exact MMSI to
set and waits for you to press ENTER.

---

## 6. Run an experiment
General form:
```bash
python3 run.py <experiment> --gps <gps_port> --ais <ais_port>
```
The six:
```bash
python3 run.py ghost_static        --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
python3 run.py ghost_sweep          --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
python3 run.py impossible_jump     --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
python3 run.py fake_identity_class --gps /dev/ttyUSB0 --ais /dev/ttyUSB1   # prompts for MMSI
python3 run.py fake_epirb_location --gps /dev/ttyUSB0 --ais /dev/ttyUSB1   # prompts for MMSI
python3 run.py disappearance       --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
python3 run.py malformed_nmea      --gps /dev/ttyUSB0 --ais /dev/ttyUSB1
```
Options:
- `--dry-run`  : no hardware; prints the sentences so you can see what it does
- `--gps-baud` : default 4800
- `--ais-baud` : default 38400

Tip: run long experiments inside `tmux` so an SSH disconnect won't kill them.

The `--ais` port can be the spoofed unit's **own** output (simplest - logs what
it transmits, VDO) or a **second** transponder receiving over air (VDM, the
truer "receiver" view). Either works; own-output is the easy default.

---

## 7. Analyze a run
Each run prints the folder it created, e.g.
`results/ghost_static__20260617T140312Z`. Analyze it:
```bash
python3 analyze.py results/ghost_static__20260617T140312Z
```
Prints a PASS/REVIEW verdict per check and writes `summary.json` into the folder.

---

## 8. What every run records (results/<experiment>__<UTC>/)
| File | Contents |
|------|----------|
| `metadata.json` | experiment, ports, params, manual config, start/end times |
| `capture.jsonl` | raw timestamped AIS output - ground truth, never decoded live |
| `events.jsonl`  | markers: inject start/stop, each jump, each malformation |
| `summary.json`  | analyzer verdict (after you run analyze.py) |

Raw capture + timestamps means you can re-analyze later without re-running.

---

## 9. Per-experiment notes
- **fake_identity_class / fake_epirb_location**: code can't set MMSI (menu +
  password). Runner prints the MMSI to set and waits. The intended MMSI is saved
  in metadata.json so the manual step is documented.
- **disappearance**: after injection stops, capture keeps running for a silence
  window to catch cessation. Whether the *receiver alarms* "lost target" is a
  chartplotter behavior - watch OpenCPN, or capture ALR sentences.
- **malformed_nmea**: a PASS only means output didn't vanish. The real finding
  is in capture.jsonl - look for resets, garbage, or the unit *accepting* bad
  data. events.jsonl timestamps each malformation so you can line up any
  misbehavior to its cause.

---

## 10. Running across all three transponders
Rewire the two adapters to the next unit (or use different ttyUSB ports if all
three are wired at once) and rerun the same commands. Each run timestamps its
own folder, so nothing is overwritten. Set each unit's identity first.

---

## 11. Editing experiments
All six are plain data in `experiments.py` - change coordinates, MMSIs,
durations, jump distance, malformation spacing there. No need to touch the
runner. Keep MMSIs in the TEST / reserved-pattern ranges so nothing resembles a
real vessel.

---

## 12. Standalone GPS simulator
`gps_sim.py` is the general-purpose injector (static / move / waypoints) for
manual testing outside the experiment framework:
```bash
python3 gps_sim.py --port /dev/ttyUSB0 --baud 4800 static 42.35 -70.90
python3 gps_sim.py --port /dev/ttyUSB0 --baud 4800 move 42.35 -70.90 --speed 8 --course 90
```
