#!/usr/bin/env bash
# One-time setup on the Raspberry Pi.
set -e
echo "Installing Python dependencies..."
pip install -r requirements.txt --break-system-packages
echo
echo "Done. Now find your serial ports:"
echo "  ls /dev/serial/by-id/    (stable names - preferred)"
echo "  ls /dev/ttyUSB*          (quick check)"
echo
echo "Then run an experiment, e.g.:"
echo "  python3 run.py ghost_static --gps /dev/ttyUSB0 --ais /dev/ttyUSB1"
