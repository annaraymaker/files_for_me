#!/usr/bin/env python3
"""Overnight battery for one vendor: run the conformance suite, then the side-channel
timing probe, each followed by its analyzer. Designed to be set running and left.

RESILIENT BY DESIGN: a failure in one stage does NOT abort the others - if conformance
succeeds but the side-channel run errors, you still wake up to conformance results and
a clear report of what failed. Everything is streamed to the console AND saved to a
timestamped master log, so progress is visible if you check mid-run and recoverable
after. Ctrl-C is handled: it stops the current stage and still prints the summary.

USAGE
-----
  python3 run_all.py --gps /dev/ttyUSB0 --ais /dev/ttyUSB1 --vendor Furuno

  # common options
  --skip-conformance / --skip-sidechannel   run only one battery
  --gap / --settle                          conformance timing
  --sc-trials / --sc-doses / --sc-targets   side-channel config
  --sc-baseline-s / --sc-recovery-s         side-channel timing
  --dry-run                                 structure check, no serial I/O

Run it under tmux so it survives disconnect:
  tmux new -s ais
  python3 run_all.py --gps /dev/ttyUSB0 --ais /dev/ttyUSB1 --vendor Furuno 2>&1 | tee -a run.log
  # detach: Ctrl-b then d ; reattach: tmux attach -t ais
"""
import argparse
import os
import subprocess
import sys
import time
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))


def ts():
    return datetime.now().strftime("%H:%M:%S")


def banner(msg, logf):
    line = "=" * 70
    for s in (line, f"  {msg}", line):
        print(s, flush=True)
        logf.write(s + "\n"); logf.flush()


def stream(cmd, logf):
    """Run cmd, streaming stdout+stderr to console and log in real time.
    Returns (returncode, captured_lines)."""
    logf.write(f"\n$ {' '.join(cmd)}\n"); logf.flush()
    print(f"\n$ {' '.join(cmd)}", flush=True)
    lines = []
    proc = subprocess.Popen(cmd, cwd=HERE, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, bufsize=1)
    try:
        for line in proc.stdout:
            sys.stdout.write(line); sys.stdout.flush()
            logf.write(line); logf.flush()
            lines.append(line.rstrip("\n"))
        proc.wait()
    except KeyboardInterrupt:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()
        raise
    return proc.returncode, lines


def find_rundir(lines):
    """Both run scripts print 'analyze: python3 analyze_X.py <rundir>'. Extract it."""
    for line in reversed(lines):
        if "analyze:" in line and ".py" in line:
            return line.split(".py", 1)[1].strip().split()[0]
    # fallback: a 'wrote <dir>' line
    for line in reversed(lines):
        if line.strip().startswith("wrote "):
            return line.strip().split("wrote ", 1)[1].strip()
    return None


def run_stage(name, run_cmd, analyze_script, logf, results):
    """Run one battery (the run, then its analyzer). Records outcome; never raises
    except KeyboardInterrupt."""
    banner(f"[{ts()}] START {name}", logf)
    t0 = time.time()
    try:
        rc, lines = stream(run_cmd, logf)
    except KeyboardInterrupt:
        results.append((name, "INTERRUPTED", None)); raise
    except Exception as e:
        banner(f"[{ts()}] {name} run ERRORED: {e}", logf)
        results.append((name, f"RUN-ERROR: {e}", None)); return
    if rc != 0:
        banner(f"[{ts()}] {name} run exited rc={rc} (continuing to next stage)", logf)
        results.append((name, f"RUN-FAILED rc={rc}", None))
        # still try to analyze whatever was produced
    rundir = find_rundir(lines)
    if not rundir:
        banner(f"[{ts()}] {name}: could not locate result dir; skipping analysis", logf)
        results.append((name, "NO-RESULT-DIR", None)); return
    # run the analyzer (failure here is non-fatal; raw data is safe on disk)
    try:
        arc, _ = stream([sys.executable, analyze_script, rundir], logf)
        status = "OK" if (rc == 0 and arc == 0) else f"run_rc={rc},analyze_rc={arc}"
    except KeyboardInterrupt:
        results.append((name, "INTERRUPTED", rundir)); raise
    except Exception as e:
        banner(f"[{ts()}] {name} analyze ERRORED: {e}", logf)
        status = f"ANALYZE-ERROR: {e}"
    dt = (time.time() - t0) / 60.0
    banner(f"[{ts()}] DONE {name} in {dt:.0f} min  ({status})", logf)
    results.append((name, status, rundir))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gps", default="/dev/ttyUSB0")
    ap.add_argument("--ais", default="/dev/ttyUSB1")
    ap.add_argument("--vendor", required=True)
    ap.add_argument("--skip-conformance", action="store_true")
    ap.add_argument("--skip-sidechannel", action="store_true")
    # conformance opts
    ap.add_argument("--gap", type=float, default=50.0)
    ap.add_argument("--settle", type=float, default=120.0)
    # side-channel opts
    ap.add_argument("--sc-trials", type=int, default=16)
    ap.add_argument("--sc-doses", default="1,10,100")
    ap.add_argument("--sc-targets", default=None)
    ap.add_argument("--sc-baseline-s", type=float, default=25.0)
    ap.add_argument("--sc-recovery-s", type=float, default=35.0)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    logpath = os.path.join(HERE, f"run_all_{args.vendor}__{stamp}.log")
    logf = open(logpath, "w")

    banner(f"OVERNIGHT BATTERY  vendor={args.vendor}  start {ts()}", logf)
    print(f"master log: {logpath}", flush=True)
    if args.dry_run:
        print("(DRY-RUN: no serial I/O)", flush=True)

    results = []
    py = sys.executable
    try:
        if not args.skip_conformance:
            cmd = [py, "run_conformance.py", "--gps", args.gps, "--ais", args.ais,
                   "--vendor", args.vendor, "--gap", str(args.gap),
                   "--settle", str(args.settle)]
            if args.dry_run:
                cmd.append("--dry-run")
            run_stage("CONFORMANCE", cmd, "analyze_conformance.py", logf, results)
        else:
            banner("skipping conformance", logf)

        if not args.skip_sidechannel:
            cmd = [py, "run_sidechannel.py", "--gps", args.gps, "--ais", args.ais,
                   "--vendor", args.vendor, "--trials", str(args.sc_trials),
                   "--doses", args.sc_doses, "--baseline-s", str(args.sc_baseline_s),
                   "--recovery-s", str(args.sc_recovery_s)]
            if args.sc_targets:
                cmd += ["--targets", args.sc_targets]
            if args.dry_run:
                cmd.append("--dry-run")
            run_stage("SIDECHANNEL", cmd, "analyze_sidechannel.py", logf, results)
        else:
            banner("skipping side-channel", logf)
    except KeyboardInterrupt:
        banner(f"[{ts()}] INTERRUPTED by user", logf)

    # final summary
    banner(f"SUMMARY  vendor={args.vendor}  end {ts()}", logf)
    for name, status, rundir in results:
        line = f"  {name:14s} {status}"
        if rundir:
            line += f"\n                 results: {rundir}"
        print(line, flush=True); logf.write(line + "\n")
    print(f"\nmaster log saved: {logpath}", flush=True)
    logf.write(f"\nmaster log saved: {logpath}\n"); logf.close()


if __name__ == "__main__":
    main()
